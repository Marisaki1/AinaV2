from django.http import JsonResponse


class LocalHeaders:
    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        if request.META.get("REMOTE_ADDR") not in ("127.0.0.1", "::1", None):
            return JsonResponse(
                {"error": "WorldBuilder accepts connections from this computer only."},
                status=403,
            )
        response = self.get_response(request)
        response["X-Content-Type-Options"] = "nosniff"
        response["Referrer-Policy"] = "same-origin"
        response["Cross-Origin-Resource-Policy"] = "same-origin"
        response["X-Frame-Options"] = "DENY"
        response["Content-Security-Policy"] = (
            "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data: blob: https: http:; font-src 'self' data:; connect-src 'self'; frame-src 'none'; object-src 'none'; base-uri 'self'; form-action 'self'"
        )
        response["Cache-Control"] = (
            "no-store"
            if request.path.startswith(("/api/", "/media/")) or request.path == "/"
            else "no-cache"
        )
        return response
